//
//  MarkdownTextEditor.swift
//  Notis
//
//  Created by Mike on 11/1/25.
//

import SwiftUI

struct MarkdownHighlightedText: View {
    let text: String
    let fontSize: CGFloat
    let isCurrentParagraph: Bool
    
    var body: some View {
        Text(attributedText)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private var attributedText: AttributedString {
        let baseColor: Color = isCurrentParagraph ? .primary : .secondary.opacity(0.3)
        
        // Handle headers first
        if text.hasPrefix("# ") {
            var attributed = AttributedString(text)
            attributed.font = .system(size: fontSize * 1.5, weight: .bold, design: .default)
            attributed.foregroundColor = baseColor
            return attributed
        } else if text.hasPrefix("## ") {
            var attributed = AttributedString(text)
            attributed.font = .system(size: fontSize * 1.3, weight: .bold, design: .default)
            attributed.foregroundColor = baseColor
            return attributed
        } else if text.hasPrefix("### ") {
            var attributed = AttributedString(text)
            attributed.font = .system(size: fontSize * 1.1, weight: .bold, design: .default)
            attributed.foregroundColor = baseColor
            return attributed
        }
        
        // For non-headers, build attributed string with markdown formatting
        var result = AttributedString()
        var currentIndex = text.startIndex
        
        // Process bold text **text**
        let boldPattern = "\\*\\*(.*?)\\*\\*"
        let italicPattern = "\\*(.*?)\\*"
        
        if let boldRegex = try? NSRegularExpression(pattern: boldPattern) {
            let nsRange = NSRange(text.startIndex..<text.endIndex, in: text)
            let boldMatches = boldRegex.matches(in: text, range: nsRange)
            
            var processedRanges: [Range<String.Index>] = []
            
            for match in boldMatches {
                if let range = Range(match.range, in: text) {
                    processedRanges.append(range)
                    
                    // Add text before match
                    if currentIndex < range.lowerBound {
                        var normalText = AttributedString(String(text[currentIndex..<range.lowerBound]))
                        normalText.font = .system(size: fontSize, design: .default)
                        normalText.foregroundColor = baseColor
                        result += normalText
                    }
                    
                    // Add bold text (without ** markers)
                    let boldContent = String(text[range].dropFirst(2).dropLast(2))
                    var boldText = AttributedString(boldContent)
                    boldText.font = .system(size: fontSize, weight: .bold, design: .default)
                    boldText.foregroundColor = baseColor
                    result += boldText
                    
                    currentIndex = range.upperBound
                }
            }
            
            // Add remaining text
            if currentIndex < text.endIndex {
                var remainingText = AttributedString(String(text[currentIndex...]))
                remainingText.font = .system(size: fontSize, design: .default)
                remainingText.foregroundColor = baseColor
                result += remainingText
            }
            
            return result.characters.isEmpty ? AttributedString(text) : result
        }
        
        // Fallback for plain text
        var attributed = AttributedString(text)
        attributed.font = .system(size: fontSize, design: .default)
        attributed.foregroundColor = baseColor
        return attributed
    }
}

struct MarkdownTextEditor: View {
    @Binding var text: String
    @Binding var isTypewriterMode: Bool
    @Binding var isFocusMode: Bool
    let fontSize: CGFloat
    let lineSpacing: CGFloat
    let onTextChange: (String) -> Void
    
    @State private var cursorPosition: Int = 0
    @FocusState private var isTextEditorFocused: Bool
    
    private var safeFontSize: CGFloat {
        guard fontSize.isFinite && fontSize > 0 else { return 16 }
        return max(10, min(72, fontSize))
    }
    
    private var safeLineSpacing: CGFloat {
        guard lineSpacing.isFinite && lineSpacing > 0 else { return 1.4 }
        return max(0.5, min(3.0, lineSpacing))
    }
    
    private var paragraphs: [String] {
        text.components(separatedBy: .newlines)
    }
    
    private var currentParagraphIndex: Int {
        let textUpToCursor = String(text.prefix(cursorPosition))
        return textUpToCursor.components(separatedBy: .newlines).count - 1
    }
    
    var body: some View {
        GeometryReader { geometry in
            ScrollViewReader { scrollProxy in
                ScrollView {
                    VStack(spacing: 0) {
                        if isTypewriterMode {
                            Spacer()
                                .frame(height: geometry.size.height / 2)
                        }
                        
                        if isFocusMode {
                            VStack(alignment: .leading, spacing: safeLineSpacing * safeFontSize * 0.5) {
                                ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, paragraph in
                                    MarkdownHighlightedText(
                                        text: paragraph.isEmpty ? " " : paragraph,
                                        fontSize: safeFontSize,
                                        isCurrentParagraph: index == currentParagraphIndex
                                    )
                                    .id("paragraph-\(index)")
                                    .onTapGesture {
                                        let paragraphStartIndex = paragraphs[0..<index].map { $0.count + 1 }.reduce(0, +)
                                        cursorPosition = min(paragraphStartIndex, text.count)
                                        isTextEditorFocused = true
                                    }
                                }
                            }
                            .padding(.horizontal)
                            .overlay(
                                TextEditor(text: $text)
                                    .font(.system(size: safeFontSize, design: .default))
                                    .lineSpacing(safeLineSpacing)
                                    .scrollContentBackground(.hidden)
                                    .background(Color.clear)
                                    .opacity(0)
                                    .focused($isTextEditorFocused)
                                    .autocorrectionDisabled(false)
                                    .onChange(of: text) { _, newValue in
                                        onTextChange(newValue)
                                        updateCursorPosition()
                                        if isTypewriterMode {
                                            let currentParagraph = currentParagraphIndex
                                            if currentParagraph < paragraphs.count {
                                                withAnimation(.easeInOut(duration: 0.3)) {
                                                    scrollProxy.scrollTo("paragraph-\(currentParagraph)", anchor: .center)
                                                }
                                            }
                                        }
                                    }
                            )
                        } else {
                            ZStack {
                                // Background markdown rendering for syntax highlighting
                                VStack(alignment: .leading, spacing: safeLineSpacing * safeFontSize * 0.5) {
                                    ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, paragraph in
                                        MarkdownHighlightedText(
                                            text: paragraph.isEmpty ? " " : paragraph,
                                            fontSize: safeFontSize,
                                            isCurrentParagraph: true
                                        )
                                        .id("paragraph-\(index)")
                                    }
                                }
                                .padding(.horizontal)
                                
                                // Transparent TextEditor overlay for editing
                                TextEditor(text: $text)
                                    .font(.system(size: safeFontSize, design: .default))
                                    .lineSpacing(safeLineSpacing)
                                    .scrollContentBackground(.hidden)
                                    .background(Color.clear)
                                    .foregroundColor(.clear) // Make text transparent to show highlighted version
                                    .focused($isTextEditorFocused)
                                    .autocorrectionDisabled(false)
                                    .onChange(of: text) { _, newValue in
                                        onTextChange(newValue)
                                        updateCursorPosition()
                                        if isTypewriterMode {
                                            let currentParagraph = currentParagraphIndex
                                            if currentParagraph < paragraphs.count {
                                                withAnimation(.easeInOut(duration: 0.3)) {
                                                    scrollProxy.scrollTo("paragraph-\(currentParagraph)", anchor: .center)
                                                }
                                            }
                                        }
                                    }
                                    .padding(.horizontal)
                            }
                        }
                        
                        if isTypewriterMode {
                            Spacer()
                                .frame(height: geometry.size.height / 2)
                        }
                    }
                }
            }
        }
        .clipped()
    }
    
    private func updateCursorPosition() {
        // This is a simplified cursor position tracking
        // In a production app, you'd want more sophisticated cursor tracking
        if let range = text.range(of: text.suffix(1), options: .backwards) {
            cursorPosition = text.distance(from: text.startIndex, to: range.lowerBound)
        }
    }
}

#Preview {
    @Previewable @State var sampleText = """
# Sample Document

This is a **bold** text and this is *italic* text.

## Second Header

Some regular content here with more text to test the editor.

### Third Level Header

- List item 1
- List item 2
- List item 3
"""
    @Previewable @State var typewriterMode = false
    @Previewable @State var focusMode = false
    
    MarkdownTextEditor(
        text: $sampleText,
        isTypewriterMode: $typewriterMode,
        isFocusMode: $focusMode,
        fontSize: 16,
        lineSpacing: 1.4
    ) { newText in
        print("Text changed: \(newText.count) characters")
    }
}