//
//  EditorView.swift
//  Notis
//
//  Created by Mike on 11/1/25.
//

import SwiftUI
import CoreData

struct EditorView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var appState: AppState
    
    @State private var showStats = false
    @State private var isFullScreen = false
    @State private var showEditorSettings = false
    @State private var showFindReplace = false
    @AppStorage("fontSize") private var fontSize: Double = 16
    @AppStorage("lineSpacing") private var lineSpacing: Double = 1.4
    @AppStorage("paragraphSpacing") private var paragraphSpacing: Double = 8
    @AppStorage("fontFamily") private var fontFamily: String = "system"
    @AppStorage("editorMargins") private var editorMargins: Double = 40
    @AppStorage("showWordCounter") private var showWordCounter: Bool = true
    @AppStorage("hideShortcutBar") private var hideShortcutBar: Bool = false
    @AppStorage("disableQuickType") private var disableQuickType: Bool = false
    
    var body: some View {
        ZStack {
            if let selectedSheet = appState.selectedSheet {
                VStack(spacing: 0) {
                    // Editor Header
                    HStack {
                        Spacer()
                        
                        // Editor Options Menu
                        Menu {
                            Button("Full Screen") {
                                withAnimation(.easeInOut(duration: 0.25)) {
                                    isFullScreen.toggle()
                                    if isFullScreen {
                                        appState.showLibrary = false
                                        appState.showSheetList = false
                                    }
                                }
                            }
                            
                            Button("Find & Replace") {
                                showFindReplace = true
                            }
                            
                            Divider()
                            
                            Button("Export...") {
                                exportSheet(selectedSheet)
                            }
                            
                            Button("Export to Obsidian") {
                                ExportService.shared.exportToObsidian(sheet: selectedSheet)
                            }
                            
                            Button("Share...") {
                                shareSheet(selectedSheet)
                            }
                            
                            Divider()
                            
                            Button("Editor Settings") {
                                showEditorSettings = true
                            }
                        } label: {
                            Image(systemName: "ellipsis")
                                .font(.system(size: 21, weight: .medium))
                                .foregroundColor(.secondary)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .menuStyle(BorderlessButtonMenuStyle())
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .background(Color.clear)
                    
                    // Stats Overlay (shown when pulled down)
                    if showStats {
                        StatsOverlay(sheet: selectedSheet)
                            .transition(.move(edge: .top))
                    }
                    
                    // Editor Content
                    MarkdownEditor(
                        sheet: selectedSheet,
                        appState: appState,
                        fontSize: Binding(
                            get: { CGFloat(fontSize) },
                            set: { fontSize = Double($0) }
                        ),
                        lineSpacing: Binding(
                            get: { CGFloat(lineSpacing) },
                            set: { lineSpacing = Double($0) }
                        ),
                        paragraphSpacing: Binding(
                            get: { CGFloat(paragraphSpacing) },
                            set: { paragraphSpacing = Double($0) }
                        ),
                        fontFamily: fontFamily,
                        editorMargins: Binding(
                            get: { CGFloat(editorMargins) },
                            set: { editorMargins = Double($0) }
                        ),
                        hideShortcutBar: hideShortcutBar,
                        disableQuickType: disableQuickType,
                        showStats: $showStats
                    )
                }
            } else {
                // Empty State
                VStack(spacing: 20) {
                    Image(systemName: "doc.text")
                        .font(.system(size: 64))
                        .foregroundColor(.secondary)
                    
                    Text("Select a sheet to start writing")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    Text("Choose a sheet from the sidebar or create a new one")
                        .font(.body)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Color(.systemBackground))
        .sheet(isPresented: $showEditorSettings) {
            EditorSettingsView(
                fontSize: $fontSize,
                lineSpacing: $lineSpacing,
                paragraphSpacing: $paragraphSpacing,
                fontFamily: $fontFamily,
                editorMargins: $editorMargins,
                showWordCounter: $showWordCounter,
                hideShortcutBar: $hideShortcutBar,
                disableQuickType: $disableQuickType,
                theme: $appState.theme,
                isTypewriterMode: $appState.isTypewriterMode,
                isFocusMode: $appState.isFocusMode
            )
        }
        .sheet(isPresented: $showFindReplace) {
            if let selectedSheet = appState.selectedSheet {
                FindReplaceView(text: Binding(
                    get: { selectedSheet.content ?? "" },
                    set: { newValue in
                        selectedSheet.content = newValue
                        try? viewContext.save()
                    }
                ))
            }
        }
        .onChange(of: isFullScreen) { _, newValue in
            if !newValue {
                // Restore panes when exiting full screen
                appState.showLibrary = true
                appState.showSheetList = true
            }
        }
    }
    
    private func exportSheet(_ sheet: Sheet) {
        // Implement export functionality
        // This could open a file picker to save as markdown, PDF, etc.
        print("Export sheet: \(sheet.title ?? "Untitled")")
    }
    
    private func shareSheet(_ sheet: Sheet) {
        // Implement share functionality
        // This could use the system share sheet
        print("Share sheet: \(sheet.title ?? "Untitled")")
    }
}

struct MarkdownEditor: View {
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var sheet: Sheet
    @ObservedObject var appState: AppState
    @Binding var fontSize: CGFloat
    @Binding var lineSpacing: CGFloat
    @Binding var paragraphSpacing: CGFloat
    let fontFamily: String
    @Binding var editorMargins: CGFloat
    let hideShortcutBar: Bool
    let disableQuickType: Bool
    @Binding var showStats: Bool
    
    @State private var content: String = ""
    @State private var saveTimer: Timer?
    @State private var isEditingTitle: Bool = false
    @State private var shouldSelectTitleText: Bool = false
    @FocusState private var titleFocused: Bool
    @FocusState private var contentFocused: Bool
    
    private func getFont(size: CGFloat, weight: Font.Weight = .regular) -> Font {
        switch fontFamily {
        case "serif":
            return .custom("Times New Roman", size: size).weight(weight)
        case "monospace":
            return .custom("Menlo", size: size).weight(weight)
        case "times":
            return .custom("Times", size: size).weight(weight)
        case "helvetica":
            return .custom("Helvetica", size: size).weight(weight)
        case "courier":
            return .custom("Courier", size: size).weight(weight)
        case "avenir":
            return .custom("Avenir", size: size).weight(weight)
        case "georgia":
            return .custom("Georgia", size: size).weight(weight)
        default:
            return .system(size: size, weight: weight, design: .default)
        }
    }
    
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    // Title Field
                    TextField("Untitled", text: Binding(
                        get: { sheet.title ?? "" },
                        set: { newTitle in
                            sheet.title = newTitle
                            scheduleAutoSave()
                        }
                    ))
                    .font(getFont(size: CGFloat(fontSize + 4), weight: .semibold))
                    .textFieldStyle(PlainTextFieldStyle())
                    .focused($titleFocused)
                    .onSubmit {
                        // When return is pressed in title, move to content
                        titleFocused = false
                        contentFocused = true
                    }
                    .onKeyPress(.tab) { _ in
                        // When tab is pressed in title, move to content
                        titleFocused = false
                        contentFocused = true
                        return .handled
                    }
                    .onAppear {
                        // Select all text for new sheets
                        if shouldSelectTitleText {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                titleFocused = true
                            }
                        }
                    }
                    .padding(.horizontal, editorMargins)
                    .padding(.top, 40)
                    .padding(.bottom, CGFloat(paragraphSpacing + 12))
                    
                    // Content Editor
                    MarkdownTextEditor(
                        text: $content,
                        isTypewriterMode: $appState.isTypewriterMode,
                        isFocusMode: $appState.isFocusMode,
                        fontSize: CGFloat(fontSize),
                        lineSpacing: CGFloat(lineSpacing),
                        paragraphSpacing: CGFloat(paragraphSpacing),
                        fontFamily: fontFamily,
                        hideShortcutBar: hideShortcutBar,
                        disableQuickType: disableQuickType
                    ) { newText in
                        content = newText
                        updateWordCount()
                        updatePreview()
                        scheduleAutoSave()
                    }
                    .padding(.horizontal, editorMargins)
                    .frame(minHeight: geometry.size.height - 120)
                    .id(sheet.id ?? UUID())
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .gesture(
                DragGesture()
                    .onEnded { gesture in
                        if gesture.translation.height > 50 {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                showStats.toggle()
                            }
                        }
                    }
            )
        }
        .onAppear {
            // Force content refresh when view appears
            loadSheetContent()
        }
        .onChange(of: sheet) { oldSheet, newSheet in
            // Save content to the OLD sheet before switching
            saveContentToSheet(oldSheet)
            // Load content from the NEW sheet
            loadSheetContent()
        }
        .onDisappear {
            saveContent()
        }
    }
    
    private func loadSheetContent() {
        // Ensure sheet has an ID - fix any corrupted sheets
        if sheet.id == nil {
            sheet.id = UUID()
            try? viewContext.save()
        }
        
        // Force Core Data refresh to ensure we have the latest data
        viewContext.refresh(sheet, mergeChanges: true)
        
        // Load content from the sheet
        content = sheet.content ?? ""
        
        // Check if this is a new sheet (empty content and title is "Untitled")
        if (sheet.title?.isEmpty == true || sheet.title == "Untitled") && (sheet.content?.isEmpty == true) {
            // Focus on title for new sheets and prepare for text selection
            shouldSelectTitleText = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                titleFocused = true
                contentFocused = false
            }
        } else {
            shouldSelectTitleText = false
        }
    }
    
    private func updateWordCount() {
        let words = content.components(separatedBy: .whitespacesAndNewlines)
            .filter { !$0.isEmpty }
        sheet.wordCount = Int32(words.count)
    }
    
    private func updatePreview() {
        let preview = content.prefix(100)
        sheet.preview = String(preview).trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func scheduleAutoSave() {
        saveTimer?.invalidate()
        saveTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: false) { _ in
            saveContent()
        }
    }
    
    private func saveContent() {
        saveContentToSheet(sheet)
    }
    
    private func saveContentToSheet(_ targetSheet: Sheet) {
        targetSheet.content = content
        targetSheet.modifiedAt = Date()
        
        do {
            try viewContext.save()
        } catch {
            print("❌ Failed to save sheet: \(error)")
        }
    }
}

struct StatsOverlay: View {
    @ObservedObject var sheet: Sheet
    
    var characterCount: Int {
        sheet.content?.count ?? 0
    }
    
    var readingTime: Int {
        // Approximate reading time: 200 words per minute
        max(1, Int(sheet.wordCount) / 200)
    }
    
    var goalProgress: Double {
        guard sheet.goalCount > 0 else { return 0 }
        let current = sheet.goalType == "words" ? Double(sheet.wordCount) : Double(characterCount)
        return min(1.0, current / Double(sheet.goalCount))
    }
    
    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 40) {
                StatItem(title: "Words", value: "\(sheet.wordCount)")
                StatItem(title: "Characters", value: "\(characterCount)")
                StatItem(title: "Reading Time", value: "\(readingTime) min")
            }
            
            if sheet.goalCount > 0 {
                VStack(spacing: 8) {
                    HStack {
                        Text("Goal Progress")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("\(Int(goalProgress * 100))%")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    ProgressView(value: goalProgress)
                        .progressViewStyle(LinearProgressViewStyle(tint: .accentColor))
                        .frame(height: 4)
                    
                    HStack {
                        let current = sheet.goalType == "words" ? Int(sheet.wordCount) : characterCount
                        Text("\(current) / \(sheet.goalCount) \(sheet.goalType ?? "words")")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                    }
                }
            }
        }
        .padding(.horizontal, 40)
        .padding(.vertical, 20)
        .background(Color(.systemGray6))
        .cornerRadius(12)
        .padding(.horizontal, 40)
        .padding(.top, 20)
    }
}

struct StatItem: View {
    let title: String
    let value: String
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.primary)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

#Preview {
    EditorView(appState: AppState())
        .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}