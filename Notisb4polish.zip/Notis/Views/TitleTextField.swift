//
//  TitleTextField.swift
//  Notis
//
//  Created by Claude on 11/2/25.
//

import SwiftUI

struct TitleTextField: View {
    @Binding var text: String
    let font: Font
    let isNewSheet: Bool
    let onReturnOrTab: () -> Void
    
    var body: some View {
        TextField("Untitled", text: $text)
            .font(font)
            .textFieldStyle(PlainTextFieldStyle())
            .onSubmit {
                onReturnOrTab()
            }
            .onKeyPress(.tab) { _ in
                onReturnOrTab()
                return .handled
            }
            .onAppear {
                // For new sheets, clear the text initially so user starts with empty field
                if isNewSheet && text == "Untitled" {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        // Select all text by clearing it first - this gives the effect of selected text
                        // since typing will replace whatever is there
                    }
                }
            }
    }
}

#Preview {
    @Previewable @State var sampleText = "Untitled"
    
    VStack {
        TitleTextField(
            text: $sampleText,
            font: .title.weight(.semibold),
            isNewSheet: true,
            onReturnOrTab: {
                print("Return or Tab pressed")
            }
        )
        
        Text("Current text: '\(sampleText)'")
            .foregroundColor(.secondary)
    }
    .padding()
}