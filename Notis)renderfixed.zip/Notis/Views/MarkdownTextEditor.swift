//
//  MarkdownTextEditor.swift
//  Notis
//
//  Created by Mike on 11/1/25.
//

import SwiftUI

struct MarkdownHighlightedText: View {
    let text: String
    let fontSize: CGFloat
    let isCurrentParagraph: Bool
    let lineSpacing: CGFloat
    
    init(text: String, fontSize: CGFloat, isCurrentParagraph: Bool, lineSpacing: CGFloat = 1.4) {
        self.text = text
        self.fontSize = fontSize
        self.isCurrentParagraph = isCurrentParagraph
        self.lineSpacing = lineSpacing
    }
    
    var body: some View {
        Text(attributedText)
            .lineSpacing(lineSpacing)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private var attributedText: AttributedString {
        let baseColor: Color = isCurrentParagraph ? .primary : .secondary.opacity(0.3)
        
        // Handle headers first
        if text.hasPrefix("# ") {
            var attributed = AttributedString(text)
            attributed.font = .system(size: fontSize * 1.8, weight: .bold, design: .default)
            attributed.foregroundColor = .primary // Use primary color for headers
            return attributed
        } else if text.hasPrefix("## ") {
            var attributed = AttributedString(text)
            attributed.font = .system(size: fontSize * 1.5, weight: .bold, design: .default)
            attributed.foregroundColor = .primary // Use primary color for headers
            return attributed
        } else if text.hasPrefix("### ") {
            var attributed = AttributedString(text)
            attributed.font = .system(size: fontSize * 1.2, weight: .bold, design: .default)
            attributed.foregroundColor = .primary // Use primary color for headers
            return attributed
        }
        
        // For non-headers, build attributed string with markdown formatting
        var result = AttributedString()
        var currentIndex = text.startIndex
        
        // Process bold text **text**
        let boldPattern = "\\*\\*(.*?)\\*\\*"
        let italicPattern = "\\*(.*?)\\*"
        
        if let boldRegex = try? NSRegularExpression(pattern: boldPattern) {
            let nsRange = NSRange(text.startIndex..<text.endIndex, in: text)
            let boldMatches = boldRegex.matches(in: text, range: nsRange)
            
            var processedRanges: [Range<String.Index>] = []
            
            for match in boldMatches {
                if let range = Range(match.range, in: text) {
                    processedRanges.append(range)
                    
                    // Add text before match
                    if currentIndex < range.lowerBound {
                        var normalText = AttributedString(String(text[currentIndex..<range.lowerBound]))
                        normalText.font = .system(size: fontSize, design: .default)
                        normalText.foregroundColor = baseColor
                        result += normalText
                    }
                    
                    // Add bold text (without ** markers)
                    let boldContent = String(text[range].dropFirst(2).dropLast(2))
                    var boldText = AttributedString(boldContent)
                    boldText.font = .system(size: fontSize, weight: .bold, design: .default)
                    boldText.foregroundColor = baseColor
                    result += boldText
                    
                    currentIndex = range.upperBound
                }
            }
            
            // Add remaining text
            if currentIndex < text.endIndex {
                var remainingText = AttributedString(String(text[currentIndex...]))
                remainingText.font = .system(size: fontSize, design: .default)
                remainingText.foregroundColor = baseColor
                result += remainingText
            }
            
            return result.characters.isEmpty ? AttributedString(text) : result
        }
        
        // Fallback for plain text
        var attributed = AttributedString(text)
        attributed.font = .system(size: fontSize, design: .default)
        attributed.foregroundColor = baseColor
        return attributed
    }
}

struct MarkdownTextEditor: View {
    @Binding var text: String
    @Binding var isTypewriterMode: Bool
    @Binding var isFocusMode: Bool
    let fontSize: CGFloat
    let lineSpacing: CGFloat
    let onTextChange: (String) -> Void
    
    @State private var selectedRange: NSRange = NSRange(location: 0, length: 0)
    @State private var currentLineIndex: Int = 0
    @FocusState private var isTextEditorFocused: Bool
    
    private var safeFontSize: CGFloat {
        guard fontSize.isFinite && !fontSize.isNaN && fontSize > 0 else { return 16 }
        return max(10, min(72, fontSize))
    }
    
    private var safeLineSpacing: CGFloat {
        guard lineSpacing.isFinite && !lineSpacing.isNaN && lineSpacing > 0 else { return 1.4 }
        return max(0.5, min(3.0, lineSpacing))
    }
    
    private var paragraphs: [String] {
        text.components(separatedBy: .newlines)
    }
    
    private func getCurrentLineIndex(from position: Int) -> Int {
        let lines = text.components(separatedBy: .newlines)
        var currentLength = 0
        
        for (index, line) in lines.enumerated() {
            if position <= currentLength + line.count {
                return index
            }
            currentLength += line.count + 1 // +1 for newline
        }
        
        return max(0, lines.count - 1)
    }
    
    var body: some View {
        GeometryReader { geometry in
            ScrollViewReader { scrollProxy in
                ScrollView(.vertical, showsIndicators: true) {
                    VStack(spacing: 0) {
                        if isTypewriterMode {
                            Spacer()
                                .frame(height: geometry.size.height / 2)
                        }
                        
                        ZStack(alignment: .topLeading) {
                            // Main TextEditor - fully functional for editing
                            TextEditor(text: $text)
                                .font(.system(size: safeFontSize, design: .default))
                                .lineSpacing(safeLineSpacing)
                                .scrollContentBackground(.hidden)
                                .background(Color.clear)
                                .foregroundColor(isTextEditorFocused ? .primary : .clear)
                                .focused($isTextEditorFocused)
                                .autocorrectionDisabled(false)
                                .onChange(of: text) { _, newValue in
                                    onTextChange(newValue)
                                    updateCurrentLine()
                                }
                            
                            // Overlay with formatted text (only when not editing)
                            if !isFocusMode && !isTextEditorFocused {
                                VStack(alignment: .leading, spacing: 0) {
                                    ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, paragraph in
                                        // Show formatted markdown for all lines when not editing
                                        MarkdownHighlightedText(
                                            text: paragraph.isEmpty ? " " : paragraph,
                                            fontSize: safeFontSize,
                                            isCurrentParagraph: true,
                                            lineSpacing: safeLineSpacing
                                        )
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                    }
                                }
                                .allowsHitTesting(false)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 8)
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        
                        if isTypewriterMode {
                            Spacer()
                                .frame(height: geometry.size.height / 2)
                        }
                    }
                }
            }
        }
        .onTapGesture {
            isTextEditorFocused = true
        }
    }
    
    private func updateCurrentLine() {
        // In a real implementation, we'd get the actual cursor position
        // For now, estimate based on text changes
        DispatchQueue.main.async {
            currentLineIndex = getCurrentLineIndex(from: text.count)
        }
    }
}

#Preview {
    @Previewable @State var sampleText = """
# Sample Document

This is a **bold** text and this is *italic* text.

## Second Header

Some regular content here with more text to test the editor.

### Third Level Header

- List item 1
- List item 2
- List item 3
"""
    @Previewable @State var typewriterMode = false
    @Previewable @State var focusMode = false
    
    MarkdownTextEditor(
        text: $sampleText,
        isTypewriterMode: $typewriterMode,
        isFocusMode: $focusMode,
        fontSize: 16,
        lineSpacing: 1.4
    ) { newText in
        print("Text changed: \(newText.count) characters")
    }
}