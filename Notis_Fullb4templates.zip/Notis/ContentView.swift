//
//  ContentView.swift
//  Notis
//
//  Created by Mike on 11/1/25.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @StateObject private var appState = AppState()
    @State private var showCommandPalette = false
    @State private var showSettings = false
    @State private var showDashboard = false
    @State private var showKeyboardShortcuts = false
    @State private var showAdvancedSearch = false
    @State private var dashboardType: DashboardType = .overview
    
    private var colorScheme: ColorScheme? {
        switch appState.theme {
        case .light:
            return .light
        case .dark:
            return .dark
        case .system:
            return nil
        }
    }
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                // Navigation Bar
                NavigationBar(appState: appState)
                
                // Main Content
                GeometryReader { geometry in
                    HStack(spacing: 0) {
                        // Library Sidebar (Pane 1) - Ulysses style
                        if appState.showLibrary {
                            LibrarySidebar(appState: appState)
                                .frame(width: UlyssesDesign.Spacing.libraryWidth)
                                .background(UlyssesDesign.Colors.libraryBg(for: colorScheme ?? .light))
                                .overlay(
                                    Rectangle()
                                        .fill(UlyssesDesign.Colors.dividerColor(for: colorScheme ?? .light))
                                        .frame(width: 0.5)
                                        .opacity(0.6),
                                    alignment: .trailing
                                )
                        }
                        
                        // Sheet List (Pane 2) - Ulysses style (now has the lighter background)
                        if appState.showSheetList {
                            SheetListView(appState: appState)
                                .frame(width: UlyssesDesign.Spacing.sheetListWidth)
                                .background(UlyssesDesign.Colors.background(for: colorScheme ?? .light))
                                .overlay(
                                    Rectangle()
                                        .fill(UlyssesDesign.Colors.dividerColor(for: colorScheme ?? .light))
                                        .frame(width: 0.5)
                                        .opacity(0.6),
                                    alignment: .trailing
                                )
                        }
                        
                        // Editor Pane(s) (Pane 3) - Ulysses style
                        if appState.showSecondaryEditor {
                            // Dual editor layout
                            HStack(spacing: 0) {
                                // Primary Editor
                                EditorView(appState: appState)
                                    .background(UlyssesDesign.Colors.background(for: colorScheme ?? .light))
                                    .onTapGesture {
                                        if appState.showLibrary {
                                            withAnimation(.easeInOut(duration: 0.25)) {
                                                appState.showLibrary = false
                                            }
                                        }
                                    }
                                
                                // Divider
                                Rectangle()
                                    .fill(UlyssesDesign.Colors.dividerColor(for: colorScheme ?? .light))
                                    .frame(width: 0.5)
                                    .opacity(0.6)
                                
                                // Secondary Editor
                                SecondaryEditorView(appState: appState)
                                    .background(UlyssesDesign.Colors.background(for: colorScheme ?? .light))
                                    .onTapGesture {
                                        if appState.showLibrary {
                                            withAnimation(.easeInOut(duration: 0.25)) {
                                                appState.showLibrary = false
                                            }
                                        }
                                    }
                            }
                        } else {
                            // Single editor layout
                            EditorView(appState: appState)
                                .frame(maxWidth: showDashboard ? .infinity : .infinity)
                                .background(UlyssesDesign.Colors.background(for: colorScheme ?? .light))
                                .onTapGesture {
                                    if appState.showLibrary {
                                        withAnimation(.easeInOut(duration: 0.25)) {
                                            appState.showLibrary = false
                                        }
                                    }
                                }
                        }
                        
                        // Dashboard Pane (Pane 4) - when Progress is selected
                        if showDashboard, let selectedSheet = appState.selectedSheet {
                            DashboardSidePanel(
                                sheet: selectedSheet,
                                dashboardType: dashboardType,
                                isPresented: $showDashboard
                            )
                            .frame(width: UlyssesDesign.Spacing.dashboardWidth)
                            .background(UlyssesDesign.Colors.libraryBg(for: colorScheme ?? .light))
                            .overlay(
                                Rectangle()
                                    .fill(UlyssesDesign.Colors.dividerColor(for: colorScheme ?? .light))
                                    .frame(width: 0.5)
                                    .opacity(0.6),
                                alignment: .leading
                            )
                            .transition(.move(edge: .trailing))
                        }
                    }
                }
            }
            
            // Command Palette Overlay
            if showCommandPalette {
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                    .onTapGesture {
                        showCommandPalette = false
                    }
                
                CommandPalette(appState: appState, isPresented: $showCommandPalette)
            }
            
            // Keyboard Shortcuts Help Overlay
            if showKeyboardShortcuts {
                KeyboardShortcutsHelp(isPresented: $showKeyboardShortcuts)
            }
            
            // Dashboard Side Panel (moved to be inline with other panes)
        }
        .environmentObject(appState)
        .environment(\.managedObjectContext, viewContext)
        .preferredColorScheme(colorScheme)
        .overlay(
            ToastOverlay()
                .allowsHitTesting(false)
                .zIndex(999)
        )
        .sheet(isPresented: $showSettings) {
            SettingsView(appState: appState, isPresented: $showSettings)
        }
        .sheet(isPresented: $showAdvancedSearch) {
            AdvancedSearchView(appState: appState)
        }
        .onReceive(NotificationCenter.default.publisher(for: .showCommandPalette)) { _ in
            showCommandPalette = true
        }
        .onReceive(NotificationCenter.default.publisher(for: .showSettings)) { _ in
            showSettings = true
        }
        .onReceive(NotificationCenter.default.publisher(for: .showAdvancedSearch)) { _ in
            showAdvancedSearch = true
        }
        .onReceive(NotificationCenter.default.publisher(for: .showKeyboardShortcuts)) { _ in
            showKeyboardShortcuts = true
        }
        .onReceive(NotificationCenter.default.publisher(for: .showDashboard)) { notification in
            if let type = notification.object as? DashboardType {
                dashboardType = type
                withAnimation(.easeInOut(duration: 0.25)) {
                    showDashboard = true
                }
            }
        }
        .onAppear {
            // Keyboard shortcuts are now implemented via SwiftUI modifiers
        }
        // Hidden keyboard shortcut buttons
        .background(
            VStack {
                Button("Command Palette") { showCommandPalette = true }
                    .keyboardShortcut("k", modifiers: .command)
                Button("New Sheet") { createNewSheet() }
                    .keyboardShortcut("n", modifiers: .command)
                Button("Settings") { showSettings = true }
                    .keyboardShortcut(",", modifiers: .command)
                Button("Toggle Library") { appState.showLibrary.toggle() }
                    .keyboardShortcut("l", modifiers: [.command, .shift])
                Button("Toggle Sheet List") { appState.showSheetList.toggle() }
                    .keyboardShortcut("r", modifiers: [.command, .shift])
                Button("Toggle Dashboard") { 
                    withAnimation(.easeInOut(duration: 0.25)) {
                        showDashboard.toggle()
                    }
                }
                    .keyboardShortcut("d", modifiers: [.command, .shift])
                Button("Toggle Focus Mode") { appState.isFocusMode.toggle() }
                    .keyboardShortcut("f", modifiers: .command)
                Button("Toggle Typewriter Mode") { appState.isTypewriterMode.toggle() }
                    .keyboardShortcut("t", modifiers: .command)
                Button("Show Keyboard Shortcuts") { showKeyboardShortcuts = true }
                    .keyboardShortcut("/", modifiers: .command)
                Button("All Panes") { appState.viewMode = .threePane }
                    .keyboardShortcut("1", modifiers: .command)
                Button("Sheets & Editor") { appState.viewMode = .sheetsOnly }
                    .keyboardShortcut("2", modifiers: .command)
                Button("Editor Only") { appState.viewMode = .editorOnly }
                    .keyboardShortcut("3", modifiers: .command)
                Button("Close Secondary Editor") { 
                    if appState.showSecondaryEditor {
                        withAnimation(.easeInOut(duration: 0.25)) {
                            appState.closeSecondaryEditor()
                        }
                    }
                }
                    .keyboardShortcut("w", modifiers: [.command, .shift])
                Button("Open in Secondary Editor") { 
                    if let selectedSheet = appState.selectedSheet {
                        withAnimation(.easeInOut(duration: 0.25)) {
                            appState.openSecondaryEditor(with: selectedSheet)
                        }
                    }
                }
                    .keyboardShortcut("o", modifiers: [.command, .shift])
            }
            .hidden()
        )
    }
    
    private func createNewSheet() {
        withAnimation {
            // Get or create a default group for new sheets
            let targetGroup: Group
            
            if let selectedGroup = appState.selectedGroup {
                targetGroup = selectedGroup
            } else {
                // Create or find default "Inbox" group
                let fetchRequest: NSFetchRequest<Group> = Group.fetchRequest()
                fetchRequest.predicate = NSPredicate(format: "name == %@ AND parent == nil", "Inbox")
                
                if let existingInbox = try? viewContext.fetch(fetchRequest).first {
                    targetGroup = existingInbox
                } else {
                    // Create new Inbox group
                    let inboxGroup = Group(context: viewContext)
                    inboxGroup.id = UUID()
                    inboxGroup.name = "Inbox"
                    inboxGroup.createdAt = Date()
                    inboxGroup.modifiedAt = Date()
                    inboxGroup.sortOrder = 0
                    targetGroup = inboxGroup
                }
            }
            
            let newSheet = Sheet(context: viewContext)
            newSheet.id = UUID()
            newSheet.title = "Untitled"
            newSheet.content = ""
            newSheet.preview = ""
            newSheet.group = targetGroup
            newSheet.createdAt = Date()
            newSheet.modifiedAt = Date()
            newSheet.isInTrash = false
            newSheet.wordCount = 0
            newSheet.goalCount = 0
            newSheet.goalType = "words"
            newSheet.sortOrder = Int32(targetGroup.sheets?.count ?? 0)
            
            do {
                try viewContext.save()
                // Select the new sheet and clear any essential selection
                appState.selectedSheet = newSheet
                appState.selectedEssential = nil
                // Also select the target group so user can see the new sheet
                appState.selectedGroup = targetGroup
            } catch {
                print("Failed to create sheet: \(error)")
            }
        }
    }
    
    private func createNewGroup() {
        withAnimation {
            let newGroup = Group(context: viewContext)
            newGroup.id = UUID()
            newGroup.name = "New Group"
            newGroup.createdAt = Date()
            newGroup.modifiedAt = Date()
            newGroup.sortOrder = 0
            
            do {
                try viewContext.save()
                appState.selectedGroup = newGroup
            } catch {
                print("Failed to create group: \(error)")
            }
        }
    }
    
}

class AppState: ObservableObject {
    @Published var selectedGroup: Group?
    @Published var selectedSheet: Sheet?
    @Published var selectedEssential: String? = nil
    @Published var secondarySheet: Sheet? = nil
    @Published var showSecondaryEditor: Bool = false
    @AppStorage("showLibrary") var showLibrary: Bool = true
    @AppStorage("showSheetList") var showSheetList: Bool = true
    @AppStorage("isTypewriterMode") var isTypewriterMode: Bool = false
    @AppStorage("isFocusMode") var isFocusMode: Bool = false
    
    @AppStorage("appTheme") private var storedTheme: String = AppTheme.system.rawValue
    @AppStorage("viewMode") private var storedViewMode: String = ViewMode.threePane.rawValue
    
    var theme: AppTheme {
        get {
            AppTheme(rawValue: storedTheme) ?? .system
        }
        set {
            storedTheme = newValue.rawValue
            objectWillChange.send()
        }
    }
    
    var viewMode: ViewMode {
        get {
            ViewMode(rawValue: storedViewMode) ?? .threePane
        }
        set {
            storedViewMode = newValue.rawValue
            // Update pane visibility based on view mode
            switch newValue {
            case .libraryOnly:
                showLibrary = true
                showSheetList = false
            case .sheetsOnly:
                showLibrary = false
                showSheetList = true
            case .editorOnly:
                showLibrary = false
                showSheetList = false
            case .threePane:
                showLibrary = true
                showSheetList = true
            }
            objectWillChange.send()
        }
    }
    
    enum AppTheme: String, CaseIterable {
        case light = "Light"
        case dark = "Dark"
        case system = "System"
    }
    
    enum ViewMode: String, CaseIterable {
        case libraryOnly = "Library"
        case sheetsOnly = "Sheets"
        case editorOnly = "Editor"
        case threePane = "All"
    }
    
    enum SheetSortOption: String, CaseIterable {
        case manual = "Manual"
        case alphabetical = "Alphabetical"
        case creationDate = "Creation Date"
        case modificationDate = "Modified Date"
        
        var systemImage: String {
            switch self {
            case .manual: return "hand.raised"
            case .alphabetical: return "textformat.abc"
            case .creationDate: return "calendar.badge.plus"
            case .modificationDate: return "calendar.badge.clock"
            }
        }
    }
    
    @AppStorage("sheetSortOption") private var storedSortOption: String = SheetSortOption.modificationDate.rawValue
    @AppStorage("sheetSortAscending") var sheetSortAscending: Bool = false
    
    var sheetSortOption: SheetSortOption {
        get {
            SheetSortOption(rawValue: storedSortOption) ?? .modificationDate
        }
        set {
            storedSortOption = newValue.rawValue
            objectWillChange.send()
        }
    }
    
    func openSecondaryEditor(with sheet: Sheet) {
        secondarySheet = sheet
        showSecondaryEditor = true
    }
    
    func closeSecondaryEditor() {
        secondarySheet = nil
        showSecondaryEditor = false
    }
}

struct SecondaryEditorView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var appState: AppState
    
    @AppStorage("fontSize") private var fontSize: Double = 16
    @AppStorage("lineSpacing") private var lineSpacing: Double = 1.4
    @AppStorage("paragraphSpacing") private var paragraphSpacing: Double = 8
    @AppStorage("fontFamily") private var fontFamily: String = "system"
    @AppStorage("editorMargins") private var editorMargins: Double = 40
    @AppStorage("hideShortcutBar") private var hideShortcutBar: Bool = false
    @AppStorage("disableQuickType") private var disableQuickType: Bool = false
    
    @State private var showStats = false
    @State private var isReadOnlyMode = false
    
    var body: some View {
        ZStack {
            if let secondarySheet = appState.secondarySheet {
                VStack(spacing: 0) {
                    // Secondary Editor Header
                    HStack {
                        // Close Secondary Editor Button
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                appState.closeSecondaryEditor()
                            }
                        }) {
                            Image(systemName: "xmark")
                                .font(.system(size: 16, weight: .medium))
                                .foregroundColor(.secondary)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .help("Close Secondary Editor")
                        
                        Spacer()
                        
                        // Sheet Title
                        Text(secondarySheet.title ?? "Untitled")
                            .font(.headline)
                            .foregroundColor(.primary)
                            .lineLimit(1)
                        
                        Spacer()
                        
                        // Favorite Button
                        FavoriteButton(sheet: secondarySheet)
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                    .background(Color.clear)
                    
                    // Stats Overlay (shown when pulled down)
                    if showStats {
                        StatsOverlay(sheet: secondarySheet)
                            .transition(.move(edge: .top))
                    }
                    
                    // Editor Content
                    MarkdownEditor(
                        sheet: secondarySheet,
                        appState: appState,
                        fontSize: Binding(
                            get: { CGFloat(fontSize) },
                            set: { fontSize = Double($0) }
                        ),
                        lineSpacing: Binding(
                            get: { CGFloat(lineSpacing) },
                            set: { lineSpacing = Double($0) }
                        ),
                        paragraphSpacing: Binding(
                            get: { CGFloat(paragraphSpacing) },
                            set: { paragraphSpacing = Double($0) }
                        ),
                        fontFamily: fontFamily,
                        editorMargins: Binding(
                            get: { CGFloat(editorMargins) },
                            set: { editorMargins = Double($0) }
                        ),
                        hideShortcutBar: hideShortcutBar,
                        disableQuickType: disableQuickType,
                        showStats: $showStats,
                        isReadOnlyMode: $isReadOnlyMode
                    )
                }
            } else {
                // Empty State
                VStack(spacing: 20) {
                    Image(systemName: "doc.text.below.doc.text")
                        .font(.system(size: 64))
                        .foregroundColor(.secondary)
                    
                    Text("Secondary Editor")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    Text("Open a sheet here using long press")
                        .font(.body)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .background(Color(.systemBackground))
    }
}

#Preview {
    ContentView()
        .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
