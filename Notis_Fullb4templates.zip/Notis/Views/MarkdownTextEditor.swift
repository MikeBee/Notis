//
//  MarkdownTextEditor.swift
//  Notis
//
//  Created by Mike on 11/1/25.
//

import SwiftUI

struct MarkdownHighlightedText: View {
    let text: String
    let fontSize: CGFloat
    let isCurrentParagraph: Bool
    let lineSpacing: CGFloat
    let paragraphSpacing: CGFloat
    let fontFamily: String
    
    init(text: String, fontSize: CGFloat, isCurrentParagraph: Bool, lineSpacing: CGFloat = 1.4, paragraphSpacing: CGFloat = 8, fontFamily: String = "system") {
        self.text = text
        self.fontSize = fontSize
        self.isCurrentParagraph = isCurrentParagraph
        self.lineSpacing = lineSpacing
        self.paragraphSpacing = paragraphSpacing
        self.fontFamily = fontFamily
    }
    
    private func getFont(size: CGFloat, weight: Font.Weight = .regular) -> Font {
        switch fontFamily {
        case "serif":
            return .custom("Times New Roman", size: size).weight(weight)
        case "monospace":
            return .custom("Menlo", size: size).weight(weight)
        case "times":
            return .custom("Times", size: size).weight(weight)
        case "helvetica":
            return .custom("Helvetica", size: size).weight(weight)
        case "courier":
            return .custom("Courier", size: size).weight(weight)
        case "avenir":
            return .custom("Avenir", size: size).weight(weight)
        case "georgia":
            return .custom("Georgia", size: size).weight(weight)
        default:
            return .system(size: size, weight: weight, design: .default)
        }
    }
    
    private func getFontForAttributedString(size: CGFloat, weight: UIFont.Weight = .regular) -> UIFont {
        switch fontFamily {
        case "serif":
            return UIFont(name: "Times New Roman", size: size) ?? UIFont.systemFont(ofSize: size, weight: weight)
        case "monospace":
            return UIFont(name: "Menlo", size: size) ?? UIFont.monospacedSystemFont(ofSize: size, weight: weight)
        case "times":
            return UIFont(name: "Times", size: size) ?? UIFont.systemFont(ofSize: size, weight: weight)
        case "helvetica":
            return UIFont(name: "Helvetica", size: size) ?? UIFont.systemFont(ofSize: size, weight: weight)
        case "courier":
            return UIFont(name: "Courier", size: size) ?? UIFont.monospacedSystemFont(ofSize: size, weight: weight)
        case "avenir":
            return UIFont(name: "Avenir", size: size) ?? UIFont.systemFont(ofSize: size, weight: weight)
        case "georgia":
            return UIFont(name: "Georgia", size: size) ?? UIFont.systemFont(ofSize: size, weight: weight)
        default:
            return UIFont.systemFont(ofSize: size, weight: weight)
        }
    }
    
    var body: some View {
        Text(attributedText)
            .lineSpacing(lineSpacing)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.bottom, text.isEmpty ? 0 : paragraphSpacing)
    }
    
    private var baseColor: Color {
        Color.primary
    }
    
    private func createHeaderAttributedString(text: String, headerLevel: Int, baseFontSize: CGFloat) -> AttributedString {
        let headerPrefixes = ["# ", "## ", "### "]
        guard headerLevel <= headerPrefixes.count else {
            var attributed = AttributedString(text)
            attributed.font = UIFont.boldSystemFont(ofSize: baseFontSize)
            return attributed
        }
        
        let prefix = headerPrefixes[headerLevel - 1]
        let headerText = String(text.dropFirst(prefix.count))
        
        // Create attributed string with both prefix and content
        var fullAttributed = AttributedString()
        
        // Add the # symbols with small, light gray styling
        var prefixAttributed = AttributedString(prefix)
        prefixAttributed.font = UIFont.systemFont(ofSize: baseFontSize * 0.5) // Half size
        prefixAttributed.foregroundColor = Color.gray.opacity(0.5) // Light gray
        
        // Add the header text with bold, large styling
        var contentAttributed = AttributedString(headerText)
        let fontMultiplier: CGFloat = headerLevel == 1 ? 1.5 : (headerLevel == 2 ? 1.3 : 1.1)
        contentAttributed.font = UIFont.boldSystemFont(ofSize: baseFontSize * fontMultiplier)
        contentAttributed.foregroundColor = Color.primary
        
        // Combine them
        fullAttributed.append(prefixAttributed)
        fullAttributed.append(contentAttributed)
        
        return fullAttributed
    }
    
    private var attributedText: AttributedString {
        let shouldShowFormatting = !isCurrentParagraph
        
        // Safe font size validation
        let safeFontSize = max(12, min(32, fontSize))
        
        if shouldShowFormatting {
            // Headers
            if text.hasPrefix("# ") {
                return createHeaderAttributedString(text: text, headerLevel: 1, baseFontSize: safeFontSize)
            } else if text.hasPrefix("## ") {
                return createHeaderAttributedString(text: text, headerLevel: 2, baseFontSize: safeFontSize)
            } else if text.hasPrefix("### ") {
                return createHeaderAttributedString(text: text, headerLevel: 3, baseFontSize: safeFontSize)
            }
            
            // Bold text
            if text.contains("**") && text.count > 4 {
                let displayText = text.replacingOccurrences(of: "**", with: "")
                var attributed = AttributedString(displayText)
                attributed.font = UIFont.boldSystemFont(ofSize: safeFontSize)
                return attributed
            }
            
            // Italic text  
            if text.contains("*") && !text.contains("**") && text.count > 2 {
                let displayText = text.replacingOccurrences(of: "*", with: "")
                var attributed = AttributedString(displayText)
                attributed.font = UIFont.italicSystemFont(ofSize: safeFontSize)
                return attributed
            }
        }
        
        // Fallback for plain text
        var attributed = AttributedString(text)
        attributed.font = UIFont.systemFont(ofSize: safeFontSize)
        return attributed
    }
}

struct MarkdownReadOnlyView: View {
    let text: String
    let fontSize: CGFloat
    let lineSpacing: CGFloat
    let paragraphSpacing: CGFloat
    let fontFamily: String
    
    init(text: String, fontSize: CGFloat, lineSpacing: CGFloat = 1.4, paragraphSpacing: CGFloat = 8, fontFamily: String = "system") {
        self.text = text
        self.fontSize = fontSize
        self.lineSpacing = lineSpacing
        self.paragraphSpacing = paragraphSpacing
        self.fontFamily = fontFamily
    }
    
    private var safeFontSize: CGFloat {
        guard fontSize.isFinite && !fontSize.isNaN && fontSize > 0 else { return 16 }
        return max(10, min(72, fontSize))
    }
    
    private var safeLineSpacing: CGFloat {
        guard lineSpacing.isFinite && !lineSpacing.isNaN && lineSpacing > 0 else { return 1.4 }
        return max(0.5, min(3.0, lineSpacing))
    }
    
    private var safeParagraphSpacing: CGFloat {
        guard paragraphSpacing.isFinite && !paragraphSpacing.isNaN && paragraphSpacing >= 0 else { return 8 }
        return max(0, min(24, paragraphSpacing))
    }
    
    private var paragraphs: [String] {
        text.components(separatedBy: .newlines)
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, paragraph in
                    MarkdownHighlightedText(
                        text: paragraph.isEmpty ? " " : paragraph,
                        fontSize: safeFontSize,
                        isCurrentParagraph: false,
                        lineSpacing: safeLineSpacing,
                        paragraphSpacing: safeParagraphSpacing,
                        fontFamily: fontFamily
                    )
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
    }
}

struct MarkdownTextEditor: View {
    @Binding var text: String
    @Binding var isTypewriterMode: Bool
    @Binding var isFocusMode: Bool
    let fontSize: CGFloat
    let lineSpacing: CGFloat
    let paragraphSpacing: CGFloat
    let fontFamily: String
    let hideShortcutBar: Bool
    let disableQuickType: Bool
    let onTextChange: (String) -> Void
    
    @State private var selectedRange: NSRange = NSRange(location: 0, length: 0)
    @State private var currentLineIndex: Int = 0
    @State private var cursorPosition: Int = 0
    @FocusState private var isTextEditorFocused: Bool
    
    private var safeFontSize: CGFloat {
        guard fontSize.isFinite && !fontSize.isNaN && fontSize > 0 else { return 16 }
        return max(10, min(72, fontSize))
    }
    
    private var safeLineSpacing: CGFloat {
        guard lineSpacing.isFinite && !lineSpacing.isNaN && lineSpacing > 0 else { return 1.4 }
        return max(0.5, min(3.0, lineSpacing))
    }
    
    private var safeParagraphSpacing: CGFloat {
        guard paragraphSpacing.isFinite && !paragraphSpacing.isNaN && paragraphSpacing >= 0 else { return 8 }
        return max(0, min(24, paragraphSpacing))
    }
    
    private func getFont(size: CGFloat, weight: Font.Weight = .regular) -> Font {
        switch fontFamily {
        case "serif":
            return .custom("Times New Roman", size: size).weight(weight)
        case "monospace":
            return .custom("Menlo", size: size).weight(weight)
        case "times":
            return .custom("Times", size: size).weight(weight)
        case "helvetica":
            return .custom("Helvetica", size: size).weight(weight)
        case "courier":
            return .custom("Courier", size: size).weight(weight)
        case "avenir":
            return .custom("Avenir", size: size).weight(weight)
        case "georgia":
            return .custom("Georgia", size: size).weight(weight)
        default:
            return .system(size: size, weight: weight, design: .default)
        }
    }
    
    private var paragraphs: [String] {
        text.components(separatedBy: .newlines)
    }
    
    private func getCurrentLineIndex(from position: Int) -> Int {
        let lines = text.components(separatedBy: .newlines)
        var currentLength = 0
        
        for (index, line) in lines.enumerated() {
            if position <= currentLength + line.count {
                return index
            }
            currentLength += line.count + 1 // +1 for newline
        }
        
        return max(0, lines.count - 1)
    }
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .topLeading) {
                // Main TextEditor - fully functional for editing
                TextEditor(text: $text)
                    .font(getFont(size: safeFontSize))
                    .lineSpacing(safeLineSpacing)
                    .scrollContentBackground(.hidden)
                    .background(Color.clear)
                    .foregroundColor(isFocusMode ? .clear : .primary) // Hide text in focus mode
                    .focused($isTextEditorFocused)
                    .autocorrectionDisabled(disableQuickType)
                    .padding(.top, isTypewriterMode ? geometry.size.height / 2 : 0)
                    .padding(.bottom, isTypewriterMode ? geometry.size.height / 2 : 0)
                    .toolbar {
                        if !hideShortcutBar {
                            ToolbarItemGroup(placement: .keyboard) {
                                HStack(spacing: 8) {
                                    Button("**Bold**") { insertMarkdown("**", "**") }
                                        .font(.caption)
                                    Button("*Italic*") { insertMarkdown("*", "*") }
                                        .font(.caption)
                                    Button("# Header") { insertMarkdown("# ", "") }
                                        .font(.caption)
                                    Button("Hide") { isTextEditorFocused = false }
                                        .font(.caption)
                                }
                            }
                        }
                    }
                    .onChange(of: text) { _, newValue in
                        onTextChange(newValue)
                        updateCurrentLine()
                    }
                
                // Focus Mode Overlay - Dim inactive paragraphs
                if isFocusMode {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, paragraph in
                            Text(paragraph.isEmpty ? " " : paragraph)
                                .font(getFont(size: safeFontSize))
                                .lineSpacing(safeLineSpacing)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.bottom, paragraph.isEmpty ? 0 : safeParagraphSpacing)
                                .opacity(index == currentLineIndex ? 1.0 : 0.3) // Dim inactive lines
                                .animation(.easeInOut(duration: 0.2), value: currentLineIndex)
                        }
                    }
                    .allowsHitTesting(false)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 8)
                    .padding(.top, isTypewriterMode ? geometry.size.height / 2 : 0)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
        .onTapGesture {
            isTextEditorFocused = true
        }
    }
    
    private func updateCurrentLine() {
        DispatchQueue.main.async {
            // For now, estimate cursor position - in a real implementation we'd track actual cursor
            // This simplified version assumes editing happens at the end
            let lines = text.components(separatedBy: .newlines)
            currentLineIndex = max(0, lines.count - 1)
        }
    }
    
    private func updateCurrentLineFromPosition(_ position: Int) {
        DispatchQueue.main.async {
            currentLineIndex = getCurrentLineIndex(from: position)
        }
    }
    
    private func insertMarkdown(_ prefix: String, _ suffix: String) {
        // For simple implementation, append to end of text
        // In a more sophisticated version, we'd insert at cursor position
        let currentText = text
        if suffix.isEmpty {
            // For headers and lists, add at beginning of new line
            if currentText.isEmpty || currentText.hasSuffix("\n") {
                text = currentText + prefix
            } else {
                text = currentText + "\n" + prefix
            }
        } else {
            // For bold/italic, wrap the text
            text = currentText + prefix + suffix
        }
    }
    
    private func insertTab() {
        text = text + "\t"
    }
}

#Preview {
    @Previewable @State var sampleText = """
# Sample Document

This is a **bold** text and this is *italic* text.

## Second Header

Some regular content here with more text to test the editor.

### Third Level Header

- List item 1
- List item 2
- List item 3
"""
    @Previewable @State var typewriterMode = false
    @Previewable @State var focusMode = false
    
    MarkdownTextEditor(
        text: $sampleText,
        isTypewriterMode: $typewriterMode,
        isFocusMode: $focusMode,
        fontSize: 16,
        lineSpacing: 1.4,
        paragraphSpacing: 8,
        fontFamily: "system",
        hideShortcutBar: false,
        disableQuickType: false,
        onTextChange: { newText in
            print("Text changed: \(newText.count) characters")
        }
    )
}